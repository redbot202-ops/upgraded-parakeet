module.exports = {
    level_cap: 1000,
    growth: true,
    // More skill points in growth so players feel the power as they grow bigger with score
    defineLevelSkillPoints: level => {
        if (level < 2) return 0;
        if (level <= 40) return 1;
        if (level <= 45 && (level % 2) === 1) return 1;
        if (level <= 60 && (level % 2) === 1) return 1;
        if (level % 5 === 1) return 1; // more frequent points at high levels
        return 0;
    }
}

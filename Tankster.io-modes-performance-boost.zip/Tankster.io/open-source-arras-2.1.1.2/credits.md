# Active Developers
Developers who are actively contributing to this project at the time of writing.
- `TGS`: Current Project Owner, Creator of `aps-template` (original OSA)\
- `Dogeiscut`: TODO\
- `Toothless`: TODO\
- `ZyraFAQ`: TODO\

# Former Developers
Developers who used to be active but have either quit or stopped developing.
- `AE0Hello`: Former Project Owner, Mobile Controls, Daily Tanks, In-Game UI\
- `Frostbyte`: Split upgrades, Dreadnoughts (V1 + V2 + V2AR)\
- `Helena`: March Madness\
- `Taureon`: Project Founder, Major Project Refactoring\
- `Trioplane`: TODO\

# Notable Contributors
People who have submitted code to the project but are not official developers.
- `Anguisj`: Oroboros\
- `DenisC!!!`: Hexagonal Grid, Growth Curve, 3D and 4D shapes\
- `Dolan the Protogen`: Arms Race content, Meme tanks, Team Walls, Labyrinth\
- `DRGNBOY`: Segmented 3D/4D shape colours\
- `Excel`: Clan Wars\
- `funny0_0`: More Maze Generations, Shiny Tanks, SVG Shapes, Kill Bars\
- `Greninja9257`: Fixing the mockup sizes\
- `kuoworic`: Precise Visual Tank Definitions\
- `LA3T`: Custom Wall Collisions\
- `Overlord K`: Meme tanks\
- `pr2000`: Fireworks, Multiple GameServer instances via `worker_threads`, Editor\
- `Wait What!?`: Snake code for Cocci/Rocket and Spiral branch bullets

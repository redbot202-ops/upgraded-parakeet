# Tankster.io — Real Players Only

Tankster.io is a customized multiplayer tank-arena fork based on Open Source Arras.

**Pure PvP experience: all AI bots removed.** Only real players.

## What’s improved in this build
- **Real players only:** all listed arenas use `bot_cap: 0`.
- **More mode variety without creating more workers:** the local list stays at 23 arenas so adding modes does not multiply background server workers on a phone.
- **Modes:** FFA, Maze, 2TDM, Mothership, Growth FFA, Domination, Squads, 4TDM, Growth 2TDM, Duos, Trios, Siege Classic, Labyrinth, Tag, Outbreak, Space, Blackout, Assault (Acropolis), Siege Blitz, Arms Race FFA, Train Wars, Clan Wars, and Sandbox.
- **Lower mobile workload:** each arena has a 40-player cap; default food limits were tuned down to reduce passive entities and collision work.
- **Hot-loop cleanup:** collision handling reuses each entity's collision array and avoids small throwaway arrays/sets in frequently called collision checks.
- **Branding:** Tankster.io visual branding and “Real Players Only” messaging are retained.

## Local mode roster
| ID | Mode | Port |
|----|------|------|
| la | FFA | 3001 |
| lb | Maze | 3002 |
| lc | 2TDM | 3003 |
| ld | Mothership | 3004 |
| le | Growth FFA | 3005 |
| lf | Domination | 3006 |
| lg | Squads | 3007 |
| lh | 4TDM | 3008 |
| li | Growth 2TDM | 3009 |
| lj | Clan Wars | 3010 |
| lk | Duos | 3011 |
| ll | Trios | 3012 |
| lm | Siege Classic | 3013 |
| ln | Labyrinth | 3014 |
| lo | Tag | 3015 |
| lp | Outbreak | 3016 |
| lq | Space | 3017 |
| lr | Blackout | 3018 |
| ls | Assault: Acropolis | 3019 |
| lt | Siege Blitz | 3020 |
| lu | Arms Race FFA | 3021 |
| lv | Train Wars | 3022 |
| lz | Sandbox | 3099 |

## Run on Android with Termux
Use a current Termux installation and Node.js 22 or newer.

```sh
pkg update && pkg upgrade
pkg install nodejs-lts git unzip
cd ~/storage/downloads
unzip Tankster.io-modes-added.zip   # or replace with your downloaded ZIP name
cd Tankster.io/open-source-arras-2.1.1.2
npm install
npm start
```

Keep Termux open while the server runs. Open `http://127.0.0.1:3000` in the phone browser.

## Important: multiplayer hosting
`localhost` is only reachable from the same device. For real players to join you need a public host (VPS, Railway, Render, etc.) and update `server/config.js` host/port entries accordingly. The 40-player cap and lower food limits are performance defaults; tune them up only after measuring MSPT and memory use.

## Real players only
AI bot caps are zero everywhere. Share the public URL with friends so the arena fills with actual players. Some gamemodes still spawn gameplay objects (nests, dominators, etc.) — those are not human bots.

## Project origin and license
Based on Open Source Arras. Keep the original `LICENSE` and `credits.md` when redistributing.
